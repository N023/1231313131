import { useQuery } from "@tanstack/react-query";
import type { BookPage } from "@shared/schema";

export function useBookPages() {
  return useQuery<BookPage[]>({
    queryKey: ["/api/book-pages"],
  });
}

// Fallback content in case the API fails
export const fallbackContent = [
  {
    imageUrl: "/suga.jpg",
    text: "Tu sonrisa es la melodía que quiero escuchar para siempre. Eres la inspiración detrás de mis letras y la razón por la que mi corazón late más fuerte.",
    orderIndex: 0,
  },
  {
    imageUrl: "/jungkook.jpg",
    text: "En tu mirada encuentro un universo donde perderme y en tus abrazos, un refugio donde quiero quedarme para siempre. Eres mi inspiración y mi sueño hecho realidad.",
    orderIndex: 1,
  },
  {
    imageUrl: "/jimin.jpg",
    text: "Cada vez que te miro, siento cómo el mundo se desvanece y solo quedamos tú y yo. Eres la razón de mi felicidad y el latido de mi corazón.",
    orderIndex: 2,
  }
];