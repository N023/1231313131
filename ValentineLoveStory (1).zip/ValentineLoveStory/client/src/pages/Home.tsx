import { Book } from "@/components/Book";
import { FloatingHearts } from "@/components/FloatingHearts";
import { AudioPlayer } from "@/components/AudioPlayer";

export default function Home() {
  return (
    <div className="min-h-screen w-full bg-background overflow-hidden relative">
      <FloatingHearts />
      
      <main className="container mx-auto px-4 min-h-screen flex flex-col items-center justify-center relative z-10">
        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8 text-center">
          Para ti mi amor
        </h1>
        
        <Book />
      </main>

      <AudioPlayer />
    </div>
  );
}
