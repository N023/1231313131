import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBookPages, fallbackContent } from "@/lib/content";

export function Book() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const { data: bookPages, isLoading } = useBookPages();

  const pages = bookPages?.length ? bookPages : fallbackContent;

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < pages.length - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (isLoading) {
    return <div className="w-full max-w-md mx-auto aspect-[3/4] bg-muted animate-pulse rounded-lg" />;
  }

  return (
    <div className="w-full max-w-md mx-auto aspect-[3/4] relative">
      <AnimatePresence>
        {!isOpen ? (
          <motion.div
            className="absolute inset-0 cursor-pointer bg-[url('www.paravictoriamivida.com')] bg-cover bg-center rounded-lg shadow-2xl"
            initial={false}
            animate={{ rotateY: 0 }}
            exit={{ rotateY: -180 }}
            onClick={() => setIsOpen(true)}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.5 }}
          >
            <div className="absolute inset-0 bg-primary/20 backdrop-blur-sm rounded-lg" />
            <div className="absolute inset-0 flex items-center justify-center">
              <h2 className="text-xl md:text-3xl font-bold text-white text-center p-4">
                abre esto mi vida hermosa
              </h2>
            </div>
          </motion.div>
        ) : (
          <motion.div
            className="absolute inset-0 bg-white rounded-lg shadow-2xl overflow-hidden"
            initial={{ rotateY: -180 }}
            animate={{ rotateY: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="h-full flex">
              <div className="flex-1 p-4 md:p-6 relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentPage}
                    className="h-full flex flex-col items-center justify-center gap-3 md:gap-4"
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="w-full max-h-[60vh] overflow-hidden rounded-lg">
                      <img
                        src={pages[currentPage].imageUrl}
                        alt=""
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <p className="text-sm md:text-lg text-center text-foreground mt-2 md:mt-4 px-2">
                      {pages[currentPage].text}
                    </p>
                  </motion.div>
                </AnimatePresence>

                <div className="absolute bottom-2 md:bottom-4 left-0 right-0 flex justify-center gap-4">
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-12 w-12 rounded-full"
                    onClick={handlePrevPage}
                    disabled={currentPage === 0}
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-12 w-12 rounded-full"
                    onClick={handleNextPage}
                    disabled={currentPage === pages.length - 1}
                  >
                    <ChevronRight className="h-6 w-6" />
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}