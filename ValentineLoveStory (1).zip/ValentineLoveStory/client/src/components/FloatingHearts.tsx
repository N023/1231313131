import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface Heart {
  id: number;
  x: number;
  delay: number;
}

export function FloatingHearts() {
  const [hearts, setHearts] = useState<Heart[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setHearts((current) => {
        // Remove hearts that have completed animation
        const filtered = current.filter((heart) => heart.id > Date.now() - 5000);

        // Limit maximum number of hearts for mobile performance
        if (filtered.length >= 10) return filtered;

        // Add new heart
        return [
          ...filtered,
          {
            id: Date.now(),
            x: Math.random() * 100, // Random position across screen width
            delay: Math.random() * 0.5, // Random start delay
          },
        ];
      });
    }, 500); // Reduced frequency for better performance

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {hearts.map((heart) => (
        <motion.div
          key={heart.id}
          className="absolute bottom-0 text-primary"
          initial={{ 
            x: `${heart.x}vw`,
            y: "100vh",
            scale: 0,
            opacity: 0 
          }}
          animate={{
            y: "-100vh",
            scale: [0, 1, 0.5, 1],
            opacity: [0, 1, 1, 0]
          }}
          transition={{
            duration: 4,
            delay: heart.delay,
            ease: "easeOut"
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="md:w-6 md:h-6"
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}