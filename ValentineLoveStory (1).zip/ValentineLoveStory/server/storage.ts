import { bookPages, type BookPage, type InsertBookPage } from "@shared/schema";
import { db } from "./db";
import { eq, asc } from "drizzle-orm";

export interface IStorage {
  getBookPages(): Promise<BookPage[]>;
  createBookPage(page: InsertBookPage): Promise<BookPage>;
  updateBookPage(id: number, page: Partial<InsertBookPage>): Promise<BookPage>;
  deleteBookPage(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getBookPages(): Promise<BookPage[]> {
    return await db
      .select()
      .from(bookPages)
      .orderBy(asc(bookPages.orderIndex));
  }

  async createBookPage(page: InsertBookPage): Promise<BookPage> {
    const [newPage] = await db
      .insert(bookPages)
      .values(page)
      .returning();
    return newPage;
  }

  async updateBookPage(id: number, page: Partial<InsertBookPage>): Promise<BookPage> {
    const [updatedPage] = await db
      .update(bookPages)
      .set(page)
      .where(eq(bookPages.id, id))
      .returning();
    return updatedPage;
  }

  async deleteBookPage(id: number): Promise<void> {
    await db
      .delete(bookPages)
      .where(eq(bookPages.id, id));
  }
}

export const storage = new DatabaseStorage();