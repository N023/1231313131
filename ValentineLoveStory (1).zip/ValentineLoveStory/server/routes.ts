import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookPageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Book pages API
  app.get("/api/book-pages", async (req, res) => {
    const pages = await storage.getBookPages();
    res.json(pages);
  });

  app.post("/api/book-pages", async (req, res) => {
    const result = insertBookPageSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const page = await storage.createBookPage(result.data);
    res.status(201).json(page);
  });

  const httpServer = createServer(app);
  return httpServer;
}